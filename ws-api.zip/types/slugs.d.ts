export = slugs;
declare function slugs(
  incString: string,
  separator?: string,
  preserved?: Array<string>
): string;
